#include <stdio.h>

extern int a;
extern int b;
extern int c;
extern int d;

