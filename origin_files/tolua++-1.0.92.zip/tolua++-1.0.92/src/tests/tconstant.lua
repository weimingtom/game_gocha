assert(FIRST==M.FIRST)
assert(FIRST==A.FIRST)
assert(SECOND==M.SECOND)
assert(SECOND==A.SECOND)

assert(ONE==M.ONE)
assert(ONE==A.ONE)
assert(TWO==M.TWO)
assert(TWO==A.TWO)

print("Constant test OK")
